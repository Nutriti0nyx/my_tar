#include <stdlib.h>

typedef enum{
    FALSE,
    TRUE
} bool;

int main(int ac, char** av){
    bool f_flag = FALSE;
    int * flags = calloc(5,sizeof(bool));
    for (int i = 0; i<ac;i++){
        if (av[i][0]=='-'){
            for (int j = 1;av[i][j];j++){
                if (av[i][j]=='f'){
                    f_flag = TRUE;
                } else if (av[i][j]=='c'){
                    flags[0] = TRUE;
                } else if (av[i][j]=='r'){
                    flags[1] = TRUE;
                } else if (av[i][j]=='t'){
                    flags[2] = TRUE;
                } else if (av[i][j]=='u'){
                    flags[3] = TRUE;
                } else if (av[i][j]=='x'){
                    flags[4] = TRUE;
                }
            }
        } else if (f_flag){
            char * archive = av[i];
        } else {
            
        }
    } 
}